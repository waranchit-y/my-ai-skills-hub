#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OmniVoice Studio Helper Client
Provides CLI and programmatic methods to communicate with a local OmniVoice Studio instance.
"""

import argparse
import os
import sys
import json
import urllib.request
import urllib.error

DEFAULT_ENDPOINT = "http://127.0.0.1:8000"

def check_server_health(base_url: str = DEFAULT_ENDPOINT) -> bool:
    """Check if local OmniVoice Studio backend is active."""
    url = f"{base_url}/health"
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False

def synthesize_speech(text: str, output_file: str, ref_audio: str = None, lang: str = "th", base_url: str = DEFAULT_ENDPOINT):
    """Call OmniVoice TTS API to generate speech."""
    payload = {
        "text": text,
        "language": lang,
        "speed": 1.0,
        "reference_audio_path": os.path.abspath(ref_audio) if ref_audio else None
    }
    
    url = f"{base_url}/v1/audio/speech"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
    
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            with open(output_file, "wb") as f:
                f.write(resp.read())
        print(f"[SUCCESS] Audio saved to {output_file}")
        return True
    except urllib.error.URLError as e:
        print(f"[ERROR] Could not connect to OmniVoice Studio server at {base_url}: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description="OmniVoice Studio CLI Client")
    parser.add_argument("--text", type=str, required=True, help="Text to speak")
    parser.add_argument("--out", type=str, default="output.wav", help="Output audio path")
    parser.add_argument("--ref", type=str, default=None, help="Reference audio for voice cloning")
    parser.add_argument("--lang", type=str, default="th", help="Language code (default: th)")
    parser.add_argument("--url", type=str, default=DEFAULT_ENDPOINT, help="OmniVoice server base URL")
    parser.add_argument("--check-only", action="store_true", help="Only check server availability")
    
    args = parser.parse_args()
    
    if args.check_only:
        active = check_server_health(args.url)
        print(f"Server status at {args.url}: {'ONLINE' if active else 'OFFLINE'}")
        sys.exit(0 if active else 1)
        
    synthesize_speech(args.text, args.out, args.ref, args.lang, args.url)

if __name__ == "__main__":
    main()
