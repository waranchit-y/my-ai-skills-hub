# 🎬 Automated Video Dubbing Pipeline (เวิร์กโฟลว์พากย์วิดีโอ)

ขั้นตอนการนำเสียงโคลนจาก OmniVoice Studio มาใช้พากย์ทับวิดีโออัตโนมัติ พร้อมซิงค์เข้ากับงานตัดต่อ CapCut หรือ FFmpeg

---

## เวิร์กโฟลว์ 4 สเต็ป:

### สเต็ป 1: ดึงเสียงพูดจากวิดีโอต้นฉบับ (Audio Extraction)
```bash
ffmpeg -y -i input_video.mp4 -vn -acodec pcm_s16le -ar 24000 -ac 1 dialogue_raw.wav
```

### สเต็ป 2: ถอดความพร้อมระบุช่วงเวลา (Timestamp Transcription)
ใช้โมเดล Whisper เพื่อสร้างคำบรรยายพร้อมเวลา (SRT / JSON):
- คำพูดแต่ละประโยคจะถูกบันทึกค่า `start_time` และ `end_time`

### สเต็ป 3: สังเคราะห์เสียงพากย์ใหม่ (Re-Synthesis)
- นำแต่ละบรรทัดเข้าประมวลผลผ่าน OmniVoice Studio
- ปรับสปีดเสียงให้ความยาวของเสียงสังเคราะห์ตรงกับช่องว่างเวลาของประโยคเดิม (Time-stretching / Pacing match)

### สเต็ป 4: รวมเสียงกลับเข้าคลิปวิดีโอ
- ใช้ FFmpeg รวมวิดีโอเดิม + เสียงพากย์ใหม่ + ดนตรีประกอบ BGM แบบ Sidechain Ducking
- หรือส่งออกเป็นแทร็กเสียงแยก นำไปโยนเข้าแทร็ก `Track 0` หรือ `Track 7` ใน CapCut Draft ตามสเปกของคลังกลาง
