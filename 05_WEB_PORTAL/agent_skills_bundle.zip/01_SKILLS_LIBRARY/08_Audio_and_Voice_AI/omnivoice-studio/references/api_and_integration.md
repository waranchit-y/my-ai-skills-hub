# 🔌 OmniVoice Studio: API Reference & Local Integration

คู่มือการเชื่อมต่อ OmniVoice Studio ผ่าน REST API บนเครื่องคอมพิวเตอร์ (Localhost)

---

## 1. การเปิด Local Server
ปกติ OmniVoice Studio สามารถรัน Backend ในรูปแบบ FastAPI / Uvicorn Server:
```bash
# พอร์ตเริ่มต้น 8000 หรือ 7860
python app.py --port 8000 --device cuda
```

---

## 2. API Endpoints ที่สำคัญ

### `POST /v1/audio/speech` (Text-to-Speech & Voice Cloning)
สร้างเสียงสังเคราะห์จากข้อความ หรือโคลนเสียงตามไฟล์อ้างอิง

**Request Headers:**
`Content-Type: application/json`

**Request Body (JSON):**
```json
{
  "text": "ข้อความที่ต้องการให้เสียง AI พูด",
  "language": "th",
  "reference_audio_path": "C:/Audio/my_voice_sample.wav",
  "speed": 1.0,
  "pitch": 0.0,
  "temperature": 0.7,
  "emotion": "neutral"
}
```

**Response:**
Binary Audio Stream (`audio/wav` หรือ `audio/mpeg`)

---

### `POST /v1/audio/voice-design` (Semantic Voice Design)
สร้างเสียงใหม่ตามพารามิเตอร์โดยไม่ต้องมีไฟล์เสียงอ้างอิง

**Request Body:**
```json
{
  "gender": "male",
  "age": "adult",
  "accent": "central_thai",
  "style": "authoritative_executive",
  "text": "ข้อความทดสอบเสียงที่ออกแบบใหม่"
}
```

---

### `POST /system/flush-memory`
ล้างหน่วยความจำ VRAM บนการ์ดจอหลังจากสังเคราะห์เสียงยาว เพื่อป้องกัน Out of Memory (OOM)

**Response:**
```json
{
  "status": "success",
  "freed_vram_mb": 1420
}
```
