---
name: omnivoice-studio
description: AI Voice Cloning, Text-to-Speech (TTS), Semantic Voice Design, and Automated Video Dubbing using OmniVoice Studio. Use this skill whenever the user wants to clone voices from audio samples, generate synthetic speech in multiple languages (especially Thai), design custom voice personas, automate video dubbing/translation, or build offline voice synthesis pipelines without cloud API fees.
metadata:
  version: "1.0.0"
  category: "Audio and Voice AI"
  runtime: "Local-First / Offline"
  author: "Central Agent Library"
---

# 🎙️ OmniVoice Studio (โปรแกรมและระบบโคลนเสียง AI)

สกิลสำหรับการใช้งานและควบคุม **OmniVoice Studio** ระบบสร้างเสียงพูดและโคลนเสียง AI คุณภาพสูงแบบ **Local-First (รันบนเครื่องออฟไลน์ 100% ไม่เสียค่าบริการรายเดือน ไม่ต้องพึ่งพา Cloud APIs)**

---

## 🌟 ขีดความสามารถหลัก (Core Capabilities)

1. **Zero-Shot Voice Cloning (โคลนเสียงพูดทันที):**
   - โคลนเสียงจากตัวอย่างเสียงต้นฉบับเพียงสั้นๆ **3 - 25 วินาที** โดยไม่ต้องเสียเวลาเทรนโมเดลใหม่ (Zero-shot)
   - รองรับมากกว่า **600+ ภาษาทั่วโลก** รวมถึงภาษาไทย (Thai), อังกฤษ (English), ญี่ปุ่น, จีน ฯลฯ
2. **Semantic Voice Design (ออกแบบลักษณะเสียงตามจินตนาการ):**
   - ปรับแต่งเพศ (Gender), ช่วงอายุ (Age), สำเนียง (Accent), อารมณ์ (Emotion: ตื่นเต้น, สุภาพ, ซีเรียส), ความเร็ว (Speed), ระดับเสียง (Pitch)
   - รองรับแท็กเสริมอารมณ์ เช่น `[laughter]`, `[whisper]`, `[sigh]`, `[pause]`
3. **Automated Video Dubbing (พากย์วิดีโอหลายภาษาอัตโนมัติ):**
   - ถอดเสียงต้นฉบับด้วย Whisper -> แปลภาษา -> สร้างเสียงพากย์ใหม่ด้วยเสียงที่โคลน -> มิกซ์และซิงค์เวลากลับลงวิดีโอด้วย FFmpeg
4. **Dictation & Audio Transcription (ถอดความเสียงพูด):**
   - แปลงเสียงพูดผ่านไมโครโฟนหรือไฟล์บันทึกเป็นตัวอักษรความแม่นยำสูง
5. **Local REST API & MCP Integration:**
   - เชื่อมต่อผ่าน FastAPI backend (`http://localhost:8000` หรือ Port ประจำเครื่อง) หรือเรียกใช้ผ่าน Python Script ภายในเครื่อง

---

## 🚀 ขั้นตอนการทำงานมาตรฐาน (Standard Execution Pipeline)

```mermaid
flowchart LR
    A["ไฟล์เสียงต้นแบบ (3-25s)"] --> B["Pre-Processing & Denoise"]
    B --> C["OmniVoice Engine (Zero-Shot)"]
    D["สคริปต์ข้อความ (Text)"] --> C
    C --> E["สังเคราะห์เสียง (WAV/MP3)"]
    E --> F["Video Dubbing / CapCut / Master Audio"]
```

### ขั้นที่ 1: เตรียมไฟล์เสียงอ้างอิง (Reference Audio Preparation)
- **ความยาว:** 5 ถึง 15 วินาทีคือช่วงที่ดีที่สุด (ห้ามสั้นกว่า 3 วินาที หรือยาวเกินไปจนเกิด Noise สะสม)
- **ฟอร์แมต:** WAV (16-bit / 24-bit, 24kHz หรือ 44.1kHz / 48kHz Mono)
- **คุณภาพ:** เสียงพูดชัดเจน ไม่มีเสียงดนตรีประกอบ (BGM), ไม่มีเสียงก้อง (Reverb), ไม่มีเสียงสะท้อน

### ขั้นที่ 2: เลือกโหมดการทำงาน
- **โหมด A: โคลนเสียงพากย์ (Voice Clone TTS)**
  ใช้ไฟล์เสียงอ้างอิง + ข้อความสคริปต์ที่ต้องการให้พูด
- **โหมด B: ออกแบบเสียงใหม่ (Voice Design)**
  กำหนด Parameter หรือ Prompt: `เพศชาย วัย 35 ปี น้ำเสียงสุขุม นุ่มลึก สไตล์ผู้บริหาร`
- **โหมด C: พากย์ทับวิดีโอ (Video Dubbing)**
  ดึงเสียงจากวิดีโอ -> แปลง Subtitle -> สังเคราะห์เสียงใหม่ตามไทม์โค้ด

### ขั้นที่ 3: สังเคราะห์เสียงและส่งออกผลลัพธ์
- ตรวจสอบความถูกต้องของการออกเสียงภาษาไทย วรรณยุกต์ และการเว้นวรรค
- ทำ Audio Normalization (-14 LUFS ถึง -16 LUFS สำหรับคอนเทนต์ออนไลน์)

---

## 💻 การสั่งงานผ่าน Python API & Local Server

### 1. เรียกใช้งานผ่าน Python Client Script
```python
import requests
import json

SERVER_URL = "http://127.0.0.1:8000"

def clone_and_speak(text: str, reference_audio_path: str, output_path: str, language: str = "th"):
    payload = {
        "text": text,
        "language": language,
        "speed": 1.0,
        "reference_audio": reference_audio_path
    }
    response = requests.post(f"{SERVER_URL}/v1/audio/speech", json=payload)
    if response.status_code == 200:
        with open(output_path, "wb") as f:
            f.write(response.content)
        print(f"✅ บันทึกเสียงเรียบร้อย: {output_path}")
    else:
        print(f"❌ เกิดข้อผิดพลาด: {response.text}")
```

### 2. เรียกผ่าน CLI / Helper Script
สคริปต์สำเร็จรูปในโฟลเดอร์นี้:
`python scripts/omnivoice_client.py --text "สวัสดีครับ ยินดีต้อนรับสู่ระบบ" --ref "sample.wav" --out "result.wav"`

---

## 🛡️ Guardrails & บทเรียนสำคัญที่สุดจากการทดสอบจริง (Lessons Learned)

> [!IMPORTANT]
> **ทำไมทำผ่าน VoiceStudio ถึงเสียงชัดไม่เพี้ยน แต่เขียนสคริปต์ยิงตรงถึงเพี้ยน/เป็นต่างดาว:**
>
> 1. **กฎเหล็กเรื่อง Audio-Text Alignment (จุดตายสำคัญที่สุด):**
>    - โมเดล Zero-Shot Voice Cloning (เช่น OmniVoice) ใช้กลไก Cross-Attention / In-Context Conditioning
>    - **Reference Text จะต้องตรงกับคำพูดใน Reference Audio แบบคำต่อคำ 100%!**
>    - ในการทดสอบด้วยสคริปต์ก่อนหน้า ตัวอย่างเสียงพูดจริงยาว 12 วินาทีคือ *"วันนี้ไม่ได้เปิดกราฟเลยครับ พาตัวเองออกมานั่งอ่านหนังสือ..."* แต่สคริปต์ฮาร์ดโค้ดส่ง `ref_text = "อันนี้เป็นระบบสมบูรณ์แบบ"` เข้าไป โมเดลเกิดภาวะ Phoneme-to-Audio Desynchronization ทำให้เสียงแตก ลากยาวเป็น 43 วินาที และพึมพำไม่เป็นภาษา
>    - ขณะที่ **VoiceStudio GUI มีระบบ WhisperX (large-v3) ถอดเสียงตัวอย่างอัตโนมัติ** ทำให้ได้ `ref_text` ที่ตรงกับเสียงพูดเป๊ะ 100% โมเดลจึงสังเคราะห์เสียงออกมาได้ชัดเจน ถูกต้อง และไม่เพี้ยน
>
> 2. **Pipeline Pre & Post-Processing ของ VoiceStudio:**
>    - **Text Normalization:** ตัดคำไทย (`pythainlp`), ปรับปรุงการลากเสียง ("ทุกคนนน" -> Token ที่ถูกต้อง), และจัดการคำทับศัพท์ภาษาอังกฤษ ("Win Rate", "The Universal Trading Journal")
>    - **Chunked TTS:** แบ่งประโยคยาวเพื่อป้องกันโมเดล Diffusion หลุดลูป
>    - **Mastering & Clean-up (`pedalboard`):** ตัดเสียงเงียบหัวท้าย (-40 dBFS trim) และปรับระดับความดัง (Loudness Normalization) ให้คมชัด สม่ำเสมอ
>
> 💡 **แนวทางปฏิบัติที่ดีที่สุด:** 
> ใช้ Voice Profile ที่บันทึกผ่าน VoiceStudio หรือเรียกใช้งานผ่าน VoiceStudio Internal Engine/API เสมอ ห้ามส่ง `ref_text` มั่วหรือเดาคำพูดเด็ดขาด
> 2. **การโคลนเสียงภาษาไทย:** หากต้องการโคลนเสียงภาษาไทยคุณภาพสูง ห้ามใช้เอนจิน OmniVoice เดี่ยวๆ ให้ใช้ **GPT-SoVITS (Fine-tuned Thai)** หรือใช้ **Edge-TTS / ElevenLabs** แทน
> 3. **หากจำเป็นต้องใช้ OmniVoice:** ต้องแปลงข้อความภาษาไทยเป็น **คำอ่านภาษาอังกฤษ (Karaoke / Romanization)** หรือคำอ่านสัทอักษร (IPA) แบบเว้นวรรคคำทุกคำเท่านั้น ห้ามส่งตัวอักษรไทยติดกันเด็ดขาด

1. **ห้ามใช้ไฟล์เสียงที่มีเสียงเพลงปน (No BGM in Reference):**
   - หากไฟล์ต้นฉบับมีเสียงดนตรี ให้ใช้เครื่องมือแยกเสียง (Vocal Isolator / Demucs) ดึงเอาเฉพาะเสียงร้องก่อนเสมอ
2. **การจัดการ VRAM และ Memory Leak:**
   - หากรันหลายงานต่อเนื่อง ให้เรียก endpoint `/system/flush-memory` หรือเคลียร์ CUDA Cache (`torch.cuda.empty_cache()`) เพื่อไม่ให้โปรแกรมค้าง
3. **ป้องกัน FFmpeg Subprocess Deadlock (อิง SOP Incident #2 & #4):**
   - เมื่อนำไฟล์เสียงไปมิกซ์กับวิดีโอด้วย FFmpeg ต้องใส่แฟลก `-y` เสมอ และปิด Stdin (`stdin=subprocess.DEVNULL`)
4. **ความแม่นยำภาษาไทย:**
   - คำทับศัพท์ภาษาอังกฤษที่เขียนด้วยภาษาไทย ให้ทดสอบการอ่านออกเสียงวรรณยุกต์ก่อน หากเพี้ยนให้ใส่วรรณยุกต์กำกับหรือเขียนคำอ่านแบบสะกดตรงตัว

---

## 📚 เอกสารอ้างอิงเพิ่มเติม (References)
- [คู่มือเทคนิคการเลือกเสียงอ้างอิง (Voice Cloning Guide)](references/voice_cloning_best_practices.md)
- [เอกสาร API และการตั้งค่า Local Server](references/api_and_integration.md)
- [ขั้นตอนการทำงาน Video Dubbing ร่วมกับ CapCut](references/video_dubbing_pipeline.md)
